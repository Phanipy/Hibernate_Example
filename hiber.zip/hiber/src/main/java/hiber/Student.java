package hiber;

import javax.persistence.*;
@Entity
public class Student
{
	


	@Id
	private int Sno;
	private String Sname;
	public int getSno() {
		return Sno;
	}
	public void setSno(int sno) {
		Sno = sno;
	}
	public String getSname() {
		return Sname;
	}
	public void setSname(String sname) {
		Sname = sname;
	}
	

}
