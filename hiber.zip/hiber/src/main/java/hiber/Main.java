package hiber;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

    private static SessionFactory sessionFactory;

    public static void main(String[] args){
        try {
            // Create the session factory
            sessionFactory = new Configuration().configure().buildSessionFactory();

            // Create an employee
            Student s = new Student();
            s.setSno(22);
            s.setSname("John");
            
            Session session = sessionFactory.openSession();
            session.beginTransaction();
            session.save(s);
            session.getTransaction().commit();
            session.close();
            System.out.println("Student saved successfully.");
            // Save the employee
            //saveStudent(employee);
/*
            // Retrieve the employee
            Student retrievedStudent = getStudent(employee.getSno());
            System.out.println("Retrieved Student: " + retrievedStudent);

            // Update the employee
            retrievedStudent.setSname("phani");
            updateStudent(retrievedStudent);

            // Delete the employee
            deleteStudent(retrievedStudent);
*/
        } 
        
      
        
        finally {
            // Close the session factory
            if (sessionFactory != null) {
            	System.out.println("hello");
                sessionFactory.close();
            }
        }
    }
/*
    public static void saveStudent(Student employee) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.save(employee);
        session.getTransaction().commit();
        session.close();
        System.out.println("Student saved successfully.");
    }

    public static Student getStudent(int long1) {
        Session session = sessionFactory.openSession();
        Student employee = session.get(Student.class, long1);
        session.close();
        return employee;
    }

    public static void updateStudent(Student employee) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.update(employee);
        session.getTransaction().commit();
        session.close();
        System.out.println("Student updated successfully.");
    }

    public static void deleteStudent(Student employee) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.delete(employee);
        session.getTransaction().commit();
        session.close();
        System.out.println("Student deleted successfully.");
    }
    */
}